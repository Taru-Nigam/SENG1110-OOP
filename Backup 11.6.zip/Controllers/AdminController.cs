﻿using Microsoft.AspNetCore.Mvc;
using GameCraft.Data;
using GameCraft.Models;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering; // Add this using statement!
using System.Collections.Generic; // Add this using statement!

namespace GameCraft.Controllers
{
    // TODO: Add authorization attribute [Authorize(Roles = "Admin")] when implemented
    public class AdminController : Controller
    {
        private readonly GameCraftDbContext _context;

        public AdminController(GameCraftDbContext context)
        {
            _context = context;
        }

        private const string ValidAdminKey = "YourSecureAdminKey123"; // Set your actual admin key here

        [HttpGet]
        public IActionResult Login()
        {
            ViewData["Title"] = "Admin Login";
            return View();
        }

        [HttpPost]
        public IActionResult Login(string adminKey)
        {
            if (string.IsNullOrWhiteSpace(adminKey))
            {
                ModelState.AddModelError("", "Admin key is required.");
                return View();
            }
            if (adminKey == ValidAdminKey)
            {
                // TODO: Implement proper authentication (e.g., create admin claims, set auth cookie)
                // For now, redirect directly to admin home
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Invalid admin key.");
                return View();
            }
        }

        // GET: /Admin/ManageEmployees
        public IActionResult ManageEmployees()
        {
            // Fetch all customers who are employees (User  Type for Employee)
            // Get the Employee role's Id first
            var employeeRole = _context.UserTypes.FirstOrDefault(rt => rt.Name == "Employee");
            if (employeeRole == null)
            {
                // Handle null case if needed
                // Maybe return empty list or throw exception
                return View(new List<Customer>());
            }
            int employeeRoleId = employeeRole.Id;

            // Use employeeRoleId in query without `?.`
            var employees = _context.Customers
                                    .Where(c => c.UserType == employeeRoleId)
                                    .ToList();

            return View(employees);
        }

        // GET: /Admin/EditEmployee/5
        public IActionResult EditEmployee(int id)
        {
            var employee = _context.Customers.FirstOrDefault(c => c.CustomerId == id);
            if (employee == null)
            {
                return NotFound();
            }

            // Populate UserTypes for the dropdown, converting to SelectListItem
            ViewBag.UserTypes = _context.UserTypes.Select(r => new SelectListItem
            {
                Value = r.Id.ToString(),
                Text = r.Name
            }).ToList();

            return View(employee);
        }

        // POST: /Admin/EditEmployee/5
        [HttpPost]
        public IActionResult EditEmployee(int id, Customer editedEmployee)
        {
            if (id != editedEmployee.CustomerId)
                return BadRequest();

            if (ModelState.IsValid)
            {
                var existingEmployee = _context.Customers.FirstOrDefault(c => c.CustomerId == id);
                if (existingEmployee == null)
                    return NotFound();

                // We update basic fields but not password here for simplicity
                existingEmployee.Name = editedEmployee.Name;
                existingEmployee.Email = editedEmployee.Email;
                existingEmployee.Phone = editedEmployee.Phone;
                existingEmployee.Address = editedEmployee.Address;
                existingEmployee.City = editedEmployee.City;
                existingEmployee.PostCode = editedEmployee.PostCode;

                // Allow role change including permission level
                if (_context.UserTypes.Any(rt => rt.Id == editedEmployee.UserType))
                {
                    existingEmployee.UserType = editedEmployee.UserType;
                }

                _context.Customers.Update(existingEmployee);
                _context.SaveChanges();

                return RedirectToAction("ManageEmployees");
            }

            // If ModelState is not valid, re-populate ViewBag.UserTypes before returning the view
            ViewBag.UserTypes = _context.UserTypes.Select(r => new SelectListItem
            {
                Value = r.Id.ToString(),
                Text = r.Name
            }).ToList();
            return View(editedEmployee);
        }

        // POST: /Admin/DeleteEmployee/5
        [HttpPost]
        public IActionResult DeleteEmployee(int id)
        {
            var employee = _context.Customers.FirstOrDefault(c => c.CustomerId == id);
            if (employee == null)
                return NotFound();

            _context.Customers.Remove(employee);
            _context.SaveChanges();

            return RedirectToAction("ManageEmployees");
        }

        // GET: /Admin/ManagePrizes
        public IActionResult ManagePrizes()
        {
            var prizes = _context.Products.ToList();
            return View(prizes);
        }

        // GET: /Admin/AddOrEditPrize/{id?}
        public IActionResult AddOrEditPrize(int? id)
        {
            // Populate categories for the dropdown, converting to SelectListItem
            ViewBag.Categories = _context.Categories.Select(c => new SelectListItem
            {
                Value = c.CategoryId.ToString(),
                Text = c.Name
            }).ToList();

            if (id == null || id == 0)
            {
                // If id is null or 0, create a new Product instance for adding a new prize
                return View(new Product());
            }
            else
            {
                // If id is provided, fetch the existing product for editing
                var prize = _context.Products.FirstOrDefault(p => p.ProductId == id);
                if (prize == null)
                {
                    return NotFound(); // Return 404 if the product is not found
                }
                return View(prize); // Return the existing product for editing
            }
        }

        // POST: /Admin/AddOrEditPrize/{id?}
        [HttpPost]
        public IActionResult AddOrEditPrize(int? id, Product model)
        {
            if (ModelState.IsValid)
            {
                if (id == null || id == 0)
                {
                    // Add
                    _context.Products.Add(model);
                    _context.SaveChanges();
                    TempData["Message"] = "Prize added successfully!";
                }
                else
                {
                    // Edit
                    var existingPrize = _context.Products.FirstOrDefault(p => p.ProductId == id);
                    if (existingPrize == null)
                        return NotFound();

                    existingPrize.Name = model.Name;
                    existingPrize.Description = model.Description;
                    existingPrize.Price = model.Price;
                    existingPrize.CategoryId = model.CategoryId;

                    _context.Products.Update(existingPrize);
                    _context.SaveChanges();
                    TempData["Message"] = "Prize updated successfully!";
                }
                return RedirectToAction("ManagePrizes");
            }

            // If ModelState is not valid, re-populate ViewBag.Categories before returning the view
            ViewBag.Categories = _context.Categories.Select(c => new SelectListItem
            {
                Value = c.CategoryId.ToString(),
                Text = c.Name
            }).ToList();
            return View(model);
        }

        // POST: /Admin/DeletePrize/5
        [HttpPost]
        public IActionResult DeletePrize(int id)
        {
            var prize = _context.Products.FirstOrDefault(p => p.ProductId == id);
            if (prize == null)
                return NotFound();

            _context.Products.Remove(prize);
            _context.SaveChanges();

            return RedirectToAction("ManagePrizes");
        }

        // Optional: Admin dashboard or home redirect
        public IActionResult Index()
        {
            return RedirectToAction("ManageEmployees");
        }
    }
}
