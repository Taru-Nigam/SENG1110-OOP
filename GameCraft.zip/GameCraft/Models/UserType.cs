﻿namespace GameCraft.Models
{
    public class UserType
    {
    }
}
