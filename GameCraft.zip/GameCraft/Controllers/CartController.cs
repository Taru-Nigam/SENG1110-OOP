﻿using Microsoft.AspNetCore.Mvc;
using GameCraft.Models;

namespace GameCraft.Controllers
{
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            // Retrieve cart items from session or database
            var cartItems = new List<CartItem>(); // Replace with actual retrieval logic
            return View(cartItems);
        }
    }
}