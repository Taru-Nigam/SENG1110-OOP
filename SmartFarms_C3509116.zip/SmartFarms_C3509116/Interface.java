/*Author: Taru Nigam
 *Student No: c3509116
 *Date: 5/10/2024
 *Description: This class provides the user interface for the program.
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class Interface
{
    private Farm farm1, farm2;
    private Scanner scanner;
    
    public Interface(){
        farm1 = null;
        farm2 = null;
        scanner = new Scanner(System.in);
    }
    // Method to control the flow of the program
    public void run() {
        //this method should control the flow of the program
        int choice;
        while (true) {
            // Print Options
            System.out.println("\n1. Add Farm");
            System.out.println("2. Remove Farm");
            System.out.println("3. List Farms");
            System.out.println("4. Add Sensor To Farm");
            System.out.println("5. Remove Sensor From Farm");
            System.out.println("6. List Sensors At Farm");
            System.out.println("7. Query Sensor Type At Farm");
            System.out.println("8. Query Total Sensors And Cost At Farm");
            System.out.println("9. Exit\n");
            System.out.println("Enter Your Choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            // Select User Choices
            switch (choice) {
                case 1 -> addFarm();
                case 2 -> removeFarm();
                case 3 -> listFarms();
                case 4 -> addSensorToFarm();
                case 5 -> removeSensorFromFarm();
                case 6 -> listSensorsAtFarm();
                case 7 -> querySensorType();
                case 8 -> queryTotalSensoryAndCostAtFarm();
                case 9 -> {
                    System.out.println("\nExiting Program.");
                    return;
                }
                default -> System.out.println("\nInvalid Choice. Please Try Again.");
            }
        }
    }

    // Method to add a farm
    private void addFarm(){
        // Check if already have two farms
        if (farm1 != null && farm2 != null){
            System.out.println("\nThere are already 2 farms");
            return;
        }
        System.out.println("\nEnter Farm Name: ");
        String name = scanner.nextLine();
        if (farm1 == null){
            farm1 = new Farm(name);
        } else {
            farm2 = new Farm(name);
        }
        System.out.println("\nFarm Added Successfully!");
    }

    // Method to remove a farm
    private void removeFarm(){
        System.out.println("\nEnter Farm Name: ");
        String name = scanner.nextLine();
        if (farm1 != null && farm1.getName().equals(name)) {
            farm1 = null;
        } else if (farm2 != null && farm2.getName().equals(name)) {
            farm2 = null;
        } else {
            System.out.println("\nFarm Not Found.");
        }

        System.out.println("\nFarm removed successfully.");
    }
    // Method to add a sensor to a farm
    private void addSensorToFarm() {
        System.out.println("Enter farm name: ");
        String farmName = scanner.nextLine();

        Farm farm = getFarm(farmName);
        if (farm == null) {
            System.out.println("Farm not found.");
            return;
        }
        if (farm.hasThreeSensors()) {
            System.out.println("\nFarm already has 3 sensors.\n");
            return;
        }

        System.out.println("\nEnter Sensor Type (Temperature, Pressure, Humidity, Soil Temperature, Soil Humidity, Soil PH): ");
        String sensorType = scanner.nextLine();

        Sensor existingSensor = getExistingSensor(sensorType);
        if (existingSensor != null) {
            System.out.println("\nEnter quantity: ");
            int quantity = getPositiveIntInput();
            scanner.nextLine();

            existingSensor.setQuantity(existingSensor.getQuantity() + quantity);
            farm.addSensor(existingSensor);

        } else {
            System.out.println("\nEnter Price: ");
            double price = getPositiveDoubleInput("Price must be positive.");

            System.out.println("\nEnter Weight (kg): ");
            double weight = getPositiveDoubleInput("Weight must be positive.");

            System.out.println("\nEnter Quantity: ");
            int quantity = getPositiveIntInput();

            Sensor sensor = new Sensor(sensorType, price, weight, quantity);
            farm.addSensor(sensor);
        }

        System.out.println("\nSensor added successfully.");
    }

    // Method to remove a sensor from a farm
    private void removeSensorFromFarm(){
        System.out.println("\nEnter Farm Name: ");
        String farmName = scanner.nextLine();

        Farm farm = getFarm(farmName);
        if (farm == null){
            System.out.println("\nFarm Not Found.");
            return;
        }

        System.out.println("\nEnter Sensor Type: ");
        String sensorType = scanner.nextLine();

        Sensor sensor = getSensor(farm, sensorType);
        if (sensor == null){
            System.out.println("\nSensor Not Found In Farm.");
            return;
        }

        farm.removeSensor(sensor);
        System.out.println("\nSensor removed successfully.");
    }

    // Method to list farms
    private void listFarms(){
        // Check if no farms exist
        if (farm1 == null && farm2 == null) {
            System.out.println("\nNo Farms Exists.");
            return;
        }
        // Print each farm
        if (farm1 != null) System.out.println("\n"+farm1.getName() + " has " + farm1.getTotalSensors() + " sensors");
        if (farm2 != null) System.out.println("\n"+farm2.getName() + " has " + farm2.getTotalSensors() + " sensors");
    }

    // Method to list sensors at a farm
    private void listSensorsAtFarm() {
        System.out.print("Enter farm name: ");
        String farmName = scanner.nextLine();
        Farm farm = getFarm(farmName);
        if (farm == null) {
            System.out.println("Farm not found.");
            return;
        }
        // Check if the farm has any sensors
        if (!farm.hasAnySensors()) {
            System.out.println("No sensors found in " + farm.getName() + ".");
        } else {
            farm.printSensors();
        }
    }

    // Method to query sensor type
    private void querySensorType() {
        System.out.print("Enter sensor type: ");
        String sensorType = scanner.nextLine();

        // Check if the sensor exists in either farm
        boolean sensorFound = false;

        // Check farm1
        if (farm1 != null) {
            Sensor farm1Sensor = getSensor(farm1, sensorType);
            if (farm1Sensor != null) {
                System.out.println(sensorType + " sensor is at " + farm1.getName() + " with quantity " + farm1Sensor.getQuantity());
                sensorFound = true;
            }
        }

        // Check farm2
        if (farm2 != null) {
            Sensor farm2Sensor = getSensor(farm2, sensorType);
            if (farm2Sensor != null) {
                System.out.println(sensorType + " sensor is at " + farm2.getName() + " with quantity " + farm2Sensor.getQuantity());
                sensorFound = true;
            }
        }

        // If no sensor was found, print an error message
        if (!sensorFound) {
            System.out.println("Sensor not found.");
        }
    }

    // Method to query total sensors and cost at a farm
    private void queryTotalSensoryAndCostAtFarm(){
        System.out.println("\nEnter Farm Name: ");
        String farmName = scanner.nextLine();

        Farm farm = getFarm(farmName);
        if (farm == null){
            System.out.println("\nFarm Not Found.");
            return;
        }
        System.out.println(farm.getName() + " has " + farm.getTotalSensors() + " sensors at the cost of $" + farm.getTotalCost());
    }

    // Method to get a farm by name
    private Farm getFarm(String name){
        // Check if farm1 matches
        if (farm1 != null && farm1.getName().equals(name)) return farm1;
        // Check if farm2 matches
        if (farm2 != null && farm2.getName().equals(name)) return farm2;
        // No matching farm found
        else return null;
    }

    // Method to get a sensor from a farm by type
    private Sensor getSensor(Farm farm, String type){
        // Check if sensor1 matches
        if (farm.getSensor1() != null && farm.getSensor1().getType().equals(type)) return farm.getSensor1();
            // Check if sensor2 matches
        else if (farm.getSensor2() != null && farm.getSensor2().getType().equals(type)) return farm.getSensor2();
            // Check if sensor3 matches
        else if (farm.getSensor3() != null && farm.getSensor3().getType().equals(type)) return farm.getSensor3();
            // No matching sensor found
        else return null;
    }

    // Method to get an existing sensor by type
    private Sensor getExistingSensor(String type){
        // Check if farm1 has sensor
        if (farm1 != null){
            if (farm1.getSensor1() != null && farm1.getSensor1().getType().equals(type)) return farm1.getSensor1();
            else if (farm1.getSensor2() != null && farm1.getSensor2().getType().equals(type)) return farm1.getSensor2();
            else if (farm1.getSensor3() != null && farm1.getSensor3().getType().equals(type)) return farm1.getSensor3();
        }
        // Check if farm2 has sensor
        if (farm2 != null){
            if (farm2.getSensor1() != null && farm2.getSensor1().getType().equals(type)) return farm2.getSensor1();
            else if (farm2.getSensor2() != null && farm2.getSensor2().getType().equals(type)) return farm2.getSensor2();
            else if (farm2.getSensor3() != null && farm2.getSensor3().getType().equals(type)) return farm2.getSensor3();
        }
        // No existing sensor found
        return null;
    }
    // Method to get a positive double input from the user
    private double getPositiveDoubleInput(String errorMessage) {
        while (true) {
            try {
                double input = scanner.nextDouble();
                scanner.nextLine();
                if (input > 0) {
                    return input;
                } else {
                    System.out.println(errorMessage);
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }
     // Method to get a positive integer input from the user
    private int getPositiveIntInput() {
        while (true) {
            try {
                int input = scanner.nextInt();
                scanner.nextLine();
                if (input > 0) {
                    return input;
                } else {
                    System.out.println("Quantity must be positive.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    public static void main(String[] args) {
        Interface intFace = new Interface();
        intFace.run();
    }

}