/*Author: Taru Nigam
 *Student No: c3509116
 *Date: 5/10/2024
 *Description: This class represents a farm with its name and up to three sensors.
 */

public class Farm {
    private String name;
    private Sensor sensor1, sensor2, sensor3;
    //add comments

    public Farm(String name) {
        this.name = name;
    }

    // Method to get farm name
    public String getName() {
        return name;
    }

    // Method to get sensor1
    public Sensor getSensor1() {
        return sensor1;
    }

    // Method to get sensor2
    public Sensor getSensor2() {
        return sensor2;
    }

    // Method to get sensor3
    public Sensor getSensor3() {
        return sensor3;
    }

    // Method to add a sensor to the farm
    public void addSensor(Sensor sensor) {
        if (sensor1 == null) sensor1 = sensor;
        else if (sensor2 == null) sensor2 = sensor;
        else if (sensor3 == null) sensor3 = sensor;
        else System.out.println("Farm already has 3 sensors.");
    }

    // Method to remove a sensor from the farm
    public void removeSensor(Sensor sensor) {
        if (sensor1 != null && sensor1.getType().equals(sensor.getType())) sensor1 = null;
        else if (sensor2 != null && sensor2.getType().equals(sensor.getType())) sensor2 = null;
        else if (sensor3 != null && sensor3.getType().equals(sensor.getType())) sensor3 = null;
        else System.out.println("Sensor not found in farm.");
    }
    // Method to check if the farm has any sensors
        public boolean hasAnySensors() {
        return sensor1 != null || sensor2 != null || sensor3 != null;
    }
    
    /**
     * Checks if the farm already has 3 different types of sensors.
     *
     * @return true if the farm has 3 different types of sensors, false otherwise.
     */
    public boolean hasThreeSensors() {
        int uniqueSensors = 0;
        if (sensor1 != null) uniqueSensors++;
        if (sensor2 != null && !sensor2.getType().equals(sensor1 != null ? sensor1.getType() : "")) uniqueSensors++;
        if (sensor3 != null && !sensor3.getType().equals(sensor1 != null ? sensor1.getType() : "")
                && !sensor3.getType().equals(sensor2 != null ? sensor2.getType() : "")) uniqueSensors++;
        return uniqueSensors == 3;
    }

    // Method to get total number of sensors in farm
    public int getTotalSensors() {
        int total = 0;
        if (sensor1 != null) total += sensor1.getQuantity();
        if (sensor2 != null) total += sensor2.getQuantity();
        if (sensor3 != null) total += sensor3.getQuantity();
        return total;
    }

    // Method to get total cost of sensors in farm
    public double getTotalCost() {
        double total = 0;
        if (sensor1 != null) total += sensor1.getPrice() * sensor1.getQuantity();
        if (sensor2 != null) total += sensor2.getPrice() * sensor2.getQuantity();
        if (sensor3 != null) total += sensor3.getPrice() * sensor3.getQuantity();
        return total;
    }

    // Method to print sensors in farm
    public void printSensors() {
        // Print each sensor in farm
        if (sensor1 != null) {
            System.out.println(sensor1.getType() + " sensor has price $" + sensor1.getPrice() + ", weight " + sensor1.getWeight() + "kg, and quantity " + sensor1.getQuantity());
        }
        if (sensor2 != null) {
            System.out.println(sensor2.getType() + " sensor has price $" + sensor2.getPrice() + ", weight " + sensor2.getWeight() + "kg, and quantity " + sensor2.getQuantity());
        }
        if (sensor3 != null) {
            System.out.println(sensor3.getType() + " sensor has price $" + sensor3.getPrice() + ", weight " + sensor3.getWeight() + "kg, and quantity " + sensor3.getQuantity());
        }
    }
}