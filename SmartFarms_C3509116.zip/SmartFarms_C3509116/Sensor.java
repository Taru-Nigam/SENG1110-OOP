/*Author: Taru Nigam
 *Student No: c3509116
 *Date: 5/10/2024
 *Description: This class represents a sensor with its type, price, weight, and quantity.
 */

public class Sensor
{
    private String type;
    private double price;
    private double weight;
    private int quantity;
    //add comments

    // Allowed Sensor types/
    private static String[] ALLOWED_TYPES = {"Temperature", "Pressure", "Humidity", "Soil Temperature", "Soil Humidity", "Soil PH"};


    public Sensor(String type, double price, double weight, int quantity) {
        // Validate the sensor type
        if (!isValidType(type)) {
            throw new IllegalArgumentException("Invalid sensor type. Must be one of: " + String.join(", ", ALLOWED_TYPES));
        }

        // Validate the price, weight, and quantity
        if (price <= 0) {
            throw new IllegalArgumentException("Price must be positive.");
        }
        if (weight <= 0) {
            throw new IllegalArgumentException("Weight must be positive.");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive.");
        }

        this.type = type;
        this.price = price;
        this.weight = weight;
        this.quantity = quantity;
    }

    // Method to get sensor type
    public String getType(){
        return type;
    }

    // Method to get sensor price
    public double getPrice(){
        return price;
    }

    // Method to get sensor weight
    public double getWeight(){
        return weight;
    }

    // Method to get sensor quantity
    public int getQuantity(){
        return quantity;
    }

    // Method to set sensor quantity
    public void setQuantity(int quantity){
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive.");
        }
        this.quantity = quantity;
    }

    // Validate Sensor Type
    private boolean isValidType(String type){
        for (String allowedType : ALLOWED_TYPES){
            if (allowedType.equals(type)){
                return true;
            }
        }
        return false;
    }

}
